import streamlit as st
import pandas as pd
from sqlalchemy import create_engine

# Database connection
def get_db_connection():
    user = 'root'  # Replace with your MySQL username
    password = ''  # Replace with your MySQL password
    host = 'localhost'  # Replace with your MySQL host, e.g., 'localhost'
    port = '3306'  # Replace with your MySQL port, e.g., '3306'
    db = 'Census_DB'  # Replace with your MySQL database name
    connection_string = f'mysql+pymysql://{user}:{password}@{host}:{port}/{db}'
    engine = create_engine(connection_string)
    return engine

# Streamlit app
st.title('Census Data Analysis')

# Connect to MySQL Database
try:
    engine = get_db_connection()
    st.success('Connected to MySQL Database successfully!')
except Exception as e:
    st.error(f'Error connecting to MySQL Database: {e}')
    st.stop()

# Function to execute SQL queries
def execute_query(query):
    with engine.connect() as connection:
        result = pd.read_sql_query(query, connection)
    return result

# Define headers for the dropdown
headers = [
    'Total Population by District',
    'Literate Males and Females by District',
    'Percentage of Workers by District',
    'Households with LPG or PNG as Cooking Fuel by District',
    'Religious Composition by District',
    'Households with Internet Access by District',
    'Educational Attainment Distribution by District',
    'Households with Access to Various Modes of Transportation by District',
    'Condition of Occupied Census Houses by District',
    'Household Size Distribution by District',
    'Total Number of Households in Each State',
    'Households with Latrine Facility within the Premises by State',
    'Average Household Size by State',
    'Owned vs. Rented Households by State',
    'Distribution of Different Types of Latrine Facilities in Each State',
    'Drinking water source Near the premises Facility in Each State',
    'Average Household Income Distribution in Each State Based on the Power Parity Categories',
    'Percentage of Married Couples with Different Household Sizes in Each State',
    'Households Below the Poverty Line in Each State Based on the Power Parity Categories',
    'Overall Literacy Rate (Percentage of Literate Population) in Each State'
]

# Dropdown for selecting header
selected_header = st.selectbox('Select the Data', headers)

# Dictionary to map selected header to its corresponding query
query_mapping = {
    'Total Population by District': """
        SELECT District, SUM(Population) AS Total_Population
        FROM census_2011
        GROUP BY District
    """,
    'Literate Males and Females by District': """
        SELECT District, SUM(Literate_Male) AS Literate_Males, SUM(Literate_Female) AS Literate_Females
        FROM census_2011
        GROUP BY District
    """,
    'Percentage of Workers by District': """
        SELECT District, 
               (SUM(Male_Workers) + SUM(Female_Workers)) / SUM(Population) * 100 AS Workers_Percentage
        FROM census_2011
        GROUP BY District
    """,
    'Households with LPG or PNG as Cooking Fuel by District': """
        SELECT District, SUM(LPG_or_PNG_Households) AS Households_With_LPG_or_PNG
        FROM census_2011
        GROUP BY District
    """,
    'Religious Composition by District': """
        SELECT District, 
               SUM(Hindus) AS Hindus, 
               SUM(Muslims) AS Muslims, 
               SUM(Christians) AS Christians, 
               SUM(Sikhs) AS Sikhs, 
               SUM(Buddhists) AS Buddhists, 
               SUM(Jains) AS Jains, 
               SUM(Others_Religions) AS Others,
               SUM(Religion_Not_Stated) AS Religion_Not_Stated
        FROM census_2011
        GROUP BY District
    """,
    'Households with Internet Access by District': """
        SELECT District, 
               SUM(Households_with_Internet) AS Households_With_Internet_Access
        FROM census_2011
        GROUP BY District
    """,
'Total Population by District': """
        SELECT District, SUM(Population) AS Total_Population
        FROM census_2011
        GROUP BY District
    """,
    'Literate Males and Females by District': """
        SELECT District, SUM(Literate_Male) AS Literate_Males, SUM(Literate_Female) AS Literate_Females
        FROM census_2011
        GROUP BY District
    """,
    'Percentage of Workers by District': """
        SELECT District, 
               (SUM(Male_Workers) + SUM(Female_Workers)) / SUM(Population) * 100 AS Workers_Percentage
        FROM census_2011
        GROUP BY District
    """,
    'Households with LPG or PNG as Cooking Fuel by District': """
        SELECT District, SUM(LPG_or_PNG_Households) AS Households_With_LPG_or_PNG
        FROM census_2011
        GROUP BY District
    """,
    'Religious Composition by District': """
        SELECT District, 
               SUM(Hindus) AS Hindus, 
               SUM(Muslims) AS Muslims, 
               SUM(Christians) AS Christians, 
               SUM(Sikhs) AS Sikhs, 
               SUM(Buddhists) AS Buddhists, 
               SUM(Jains) AS Jains, 
               SUM(Others_Religions) AS Others,
               SUM(Religion_Not_Stated) AS Religion_Not_Stated
        FROM census_2011
        GROUP BY District
    """,
    'Households with Internet Access by District': """
        SELECT District, 
               SUM(Households_with_Internet) AS Households_With_Internet_Access
        FROM census_2011
        GROUP BY District
    """,
    'Educational Attainment Distribution by District': """
        SELECT District, 
           SUM(Below_Primary_Education) AS `Below Primary`, 
           SUM(Primary_Education) AS `Primary`,
           SUM(Middle_Education) AS `Middle`,
           SUM(Secondary_Education) AS `Secondary`,
           SUM(Higher_Education) AS `Higher Secondary`,
           SUM(Graduate_Education) AS `Graduate`,
           SUM(Other_Education) AS `Other Education`
        FROM census_2011
        GROUP BY District
    """,
    'Households with Access to Various Modes of Transportation by District': """
        SELECT District, 
               SUM(Households_with_Bicycle) AS Bicycle, 
               SUM(Households_with_Car_Jeep_Van) AS Car,
               SUM(Households_with_Radio_Transistor) AS Radio,
               SUM(Households_with_Scooter_Motorcycle_Moped) AS Motorcycle,
               SUM(Households_with_Telephone_Mobile_Phone_Landline_only) AS Telephone,
               SUM(Households_with_Telephone_Mobile_Phone_Mobile_only) AS Mobile,
               SUM(Households_with_Telephone_Mobile_Phone) AS 'Telephone Mobile Phone',
               SUM(Households_with_Television) AS Television,
               SUM(Households_with_Telephone_Mobile_Phone_Both) AS 'Telephone and Mobile'
        FROM census_2011
        GROUP BY District
    """,
    'Condition of Occupied Census Houses by District': """
        SELECT District, 
               SUM(Condition_of_occupied_census_houses_Dilapidated_Households) AS Dilapidated,
               SUM(Households_with_separate_kitchen_Cooking_inside_house) AS 'With Separate Kitchen',
               SUM(Having_bathing_facility_Total_Households) AS 'with Bathing facility',
               SUM(Having_latrine_facility_within_the_premises_Total_Households) AS 'with Latrine facility',
               SUM(Ownership_Owned_Households) AS 'Ownership Owned Households',
               SUM(Ownership_Rented_Households) AS 'Ownership Rented Households',
               SUM(Type_of_bathing_facility_Enclosure_without_roof_Households) AS 'Type of bathing facility Enclosure without roof Households',
               SUM(Type_of_fuel_used_for_cooking_Any_other_Households) AS 'Type of fuel used for cooking Any other Households',
               SUM(Type_of_latrine_facility_Pit_latrine_Households) AS 'Type of latrine facility Pit latrine Households',
               SUM(Type_of_latrine_facility_Other_latrine_Households) AS 'Type of_latrine facility Other latrine Households',
               SUM(Main_source_of_drinking_water_Un_covered_well_Households) AS 'Main source of drinking water Un covered well Households',
               SUM(Main_source_of_drinking_water_Spring_Households) AS 'Main source of drinking water Spring Households',
               SUM(Main_source_of_drinking_water_River_Canal_Households) AS 'Main source of drinking water River Canal Households',
               SUM(Main_source_of_drinking_water_Other_sources_Households) AS 'Main source of drinking water Other sources Households',
               SUM(Location_of_drinking_water_source_Near_the_premises_Households) AS 'Location of drinking water source Near the premises Households',
               SUM(Location_of_drinking_water_source_Within_the_premises_Households) AS 'Location of drinking water source Within the premises Households',
               SUM(Main_source_of_drinking_water_Tank_Pond_Lake_Households) AS 'Main source of drinking water Tank Pond Lake Households',
               SUM(Main_source_of_drinking_water_Tapwater_Households) AS 'Main source of drinking water Tapwater Households',
               SUM(Main_source_of_drinking_water_Tubewell_Borehole_Households) AS 'Main source of drinking water Tubewell Borehole Households'
        FROM census_2011
        GROUP BY District
    """,
    'Household Size Distribution by District': """
        SELECT District, 
               SUM(Household_size_1_person_Households) AS '1 person',
               SUM(Household_size_2_persons_Households) AS '2 persons',
               SUM(Household_size_1_to_2_persons) AS '1 to 2 persons',
               SUM(Household_size_3_persons_Households) AS '3 persons',
               SUM(Household_size_4_persons_Households) AS '4 persons',
               SUM(Household_size_5_persons_Households) AS '5 persons',
               SUM(Household_size_3_to_5_persons_Households) AS '3 to 5 persons',
               SUM(Household_size_6_8_persons_Households) AS '6 to 8 persons',
               SUM(Household_size_9_persons_and_above_Households) AS 'more than 8 persons'
        FROM census_2011
        GROUP BY District
    """,
    'Total Number of Households in Each State': """
        SELECT `State_UT`, SUM(Households) AS Total_Households
        FROM census_2011
        GROUP BY `State_UT`
    """,
'Households with Latrine Facility within the Premises by State': """
        SELECT `State_UT`, 
               SUM(Having_latrine_facility_within_the_premises_Total_Households) AS 'Households with Latrine_Facility'
        FROM census_2011
        GROUP BY `State_UT`
    """,
    'Average Household Size by State': """
        SELECT `State_UT`, 
               SUM(Households) / SUM(Population) AS Average_Household_Size
        FROM census_2011
        GROUP BY `State_UT`
    """,
    'Owned vs. Rented Households by State': """
        SELECT `State_UT`, 
               SUM(Ownership_Owned_Households) AS 'Owned Households', 
               SUM(Ownership_Rented_Households) AS 'Rented Households'
        FROM census_2011
        GROUP BY `State_UT`
    """,
    'Distribution of Different Types of Latrine Facilities in Each State': """
        SELECT `State_UT`, 
               SUM(Type_of_latrine_facility_Pit_latrine_Households) AS 'Pit Latrine', 
               SUM(Type_of_latrine_facility_Other_latrine_Households) AS 'Other Latrine'
        FROM census_2011
        GROUP BY `State_UT`
    """,
    'Drinking water source Near the premises Facility in Each State': """
        SELECT `State_UT`, 
               SUM(Location_of_drinking_water_source_Near_the_premises_Households) AS 'Near Premises'
        FROM census_2011
        GROUP BY `State_UT`
    """,
    'Average Household Income Distribution in Each State Based on the Power Parity Categories': """
        SELECT State_UT,
       SUM(Power_Parity_Less_than_Rs_45000) AS 'Less than Rs 45000',
       SUM(Power_Parity_Rs_45000_90000) AS 'Between Rs 45000 and 90000',
       SUM(Power_Parity_Rs_90000_150000) AS 'Between Rs 90000 and 150000',
       SUM(Power_Parity_Rs_45000_150000) AS 'Between Rs 45000 and 150000',
       SUM(Power_Parity_Rs_150000_240000) AS 'Between Rs 150000 and 240000',
       SUM(Power_Parity_Rs_240000_330000) AS 'Between Rs 240000 and 330000',
       SUM(Power_Parity_Rs_150000_330000) AS 'Between Rs 150000 and 330000',
       SUM(Power_Parity_Rs_330000_425000) AS 'Between Rs 330000 and 425000',
       SUM(Power_Parity_Rs_425000_545000) AS 'Between Rs 425000 and 545000',
       SUM(Power_Parity_Rs_330000_545000) AS 'Between Rs 330000 and 545000',
       SUM(Power_Parity_Above_Rs_545000) AS 'Above Rs 545000',
       SUM(Total_Power_Parity) AS 'Total Power Parity'
        FROM census_2011
        GROUP BY `State_UT`
    """,
    'Percentage of Married Couples with Different Household Sizes in Each State': """
        SELECT State_UT,
       (SUM(Married_couples_1_Households) / SUM(Households)) * 100 AS 'Married Couples 1 (%%)',
       (SUM(Married_couples_2_Households) / SUM(Households)) * 100 AS 'Married Couples 2 (%%)',
       (SUM(Married_couples_3_Households) / SUM(Households)) * 100 AS 'Married Couples 3 (%%)',
       (SUM(Married_couples_3_or_more_Households) / SUM(Households)) * 100 AS 'Married Couples 3 or More (%%)',
       (SUM(Married_couples_4_Households) / SUM(Households)) * 100 AS 'Married Couples 4 (%%)',
       (SUM(Married_couples_5__Households) / SUM(Households)) * 100 AS 'Married Couples 5 (%%)',
       (SUM(Married_couples_None_Households) / SUM(Households)) * 100 AS 'Married Couples None (%%)'
        FROM census_2011
        GROUP BY `State_UT`
    """,
    'Households Below the Poverty Line in Each State Based on the Power Parity Categories': """
        SELECT `State_UT`, 
               SUM(Power_Parity_Less_than_Rs_45000) AS 'Households Below Poverty Line'
        FROM census_2011
        GROUP BY `State_UT`
    """,
    'Overall Literacy Rate (Percentage of Literate Population) in Each State': """
        SELECT `State_UT`, 
               (SUM(Literate) / SUM(Population)) * 100 AS 'Literacy Rate (%%)'
        FROM census_2011
        GROUP BY `State_UT`
    """

}

# Execute the selected query and display the result
if selected_header in query_mapping:
    query = query_mapping[selected_header]
    try:
        result_df = execute_query(query)
        st.write(result_df)
    except Exception as e:
        st.error(f'Error executing query: {e}')
else:
    st.warning('No data available for the selected header.')

# Close MySQL connection
engine.dispose()
